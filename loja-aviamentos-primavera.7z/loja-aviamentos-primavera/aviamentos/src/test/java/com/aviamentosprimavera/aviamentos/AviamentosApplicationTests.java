package com.aviamentosprimavera.aviamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AviamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
