package com.aviamentosprimavera.model;

public @interface Email {

}
