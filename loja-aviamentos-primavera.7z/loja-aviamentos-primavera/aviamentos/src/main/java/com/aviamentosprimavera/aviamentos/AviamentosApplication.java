package com.aviamentosprimavera.aviamentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AviamentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AviamentosApplication.class, args);
	}

}
