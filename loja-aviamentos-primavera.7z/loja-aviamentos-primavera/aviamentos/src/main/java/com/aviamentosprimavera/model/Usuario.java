package com.aviamentosprimavera.model;


public class Usuario {
    
}
