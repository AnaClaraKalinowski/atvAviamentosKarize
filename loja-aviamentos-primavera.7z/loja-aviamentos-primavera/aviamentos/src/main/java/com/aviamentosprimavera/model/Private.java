package com.aviamentosprimavera.model;

public class Private {

}
